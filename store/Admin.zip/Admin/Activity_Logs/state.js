export default () => ({
    listActivityLogs: []


})