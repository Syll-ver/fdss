export default {
    getActivityLogs(state) {
        return state.listActivityLogs;
    }
}