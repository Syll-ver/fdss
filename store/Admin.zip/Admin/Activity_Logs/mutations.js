export default {
    setActivityLogs(state, data) {
        state.listActivityLogs = data

    }
}