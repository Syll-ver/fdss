export default {
    getSignatoriesList(state){
        return state.signatoriesList
    },
}