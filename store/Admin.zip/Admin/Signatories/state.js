export default {
  signatoriesList: []
};
