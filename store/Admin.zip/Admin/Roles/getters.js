export default {
    getListRoles(state) {
        return state.listRoles;
    },

}