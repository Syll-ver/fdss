export default () => ({
    listRoles: [],
})