export default () => ({
  Users: [],
  SearchedUsers: []
});
