export default {
  getUsers(state) {
    return state.Users;
  },
  getSearchedUsers(state) {
    return state.SearchedUsers;
  }
};
