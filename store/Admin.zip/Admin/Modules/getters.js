export default {
    getListModules(state) {
        return state.listModules;
    },

}