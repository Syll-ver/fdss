export default () => ({
    listModules: [],
})