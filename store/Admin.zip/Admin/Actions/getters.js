export default {
    getListActions(state) {
        return state.listActions;
    },

}