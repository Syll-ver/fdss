export default () => ({
    listActions: [],
})